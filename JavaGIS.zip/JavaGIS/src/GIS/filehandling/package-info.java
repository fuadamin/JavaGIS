/**
 * Contains classes for file handling functionalities
 */
package GIS.filehandling;
