/**
 * Contains classes defining the available Geometries Point, Polyline, Polygon.
 */
package GIS.geometry;
