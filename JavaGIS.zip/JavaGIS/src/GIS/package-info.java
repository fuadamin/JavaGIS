/**
 * Contains the GIS class which generates a new GIS and defines the user interaction and layout.
 */
package GIS;
