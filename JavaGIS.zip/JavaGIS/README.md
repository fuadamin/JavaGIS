# JavaGIS
Study project to implement Point Polyline Polygon drawing in a Java framework using Graphics 2D and storing Geometries in a CSV file or DB
